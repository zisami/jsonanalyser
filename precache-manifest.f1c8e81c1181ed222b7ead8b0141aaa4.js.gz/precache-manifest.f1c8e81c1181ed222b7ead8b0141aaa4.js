self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bb597fe55307ba4ecb6b",
    "url": "css/app.4f554fdd.css"
  },
  {
    "revision": "b697c28ece2d31cfbf66",
    "url": "css/chunk-vendors.39c70cc5.css"
  },
  {
    "revision": "2b9b4872cd25494093c1eb14f0264a0b",
    "url": "img/jsoneditor-icons.2b9b4872.svg"
  },
  {
    "revision": "bdc6b5b1f10288387024c0cb1ac6b807",
    "url": "img/plus.bdc6b5b1.svg"
  },
  {
    "revision": "2aa5548f19208b37483496f99e32be0a",
    "url": "index.html"
  },
  {
    "revision": "22a1ce63e390e2706f44",
    "url": "js/about.7226b809.js"
  },
  {
    "revision": "bb597fe55307ba4ecb6b",
    "url": "js/app.af8fb1c2.js"
  },
  {
    "revision": "b697c28ece2d31cfbf66",
    "url": "js/chunk-vendors.482ad5fd.js"
  },
  {
    "revision": "fcc63f8843a5234f4efd3d617100b650",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);